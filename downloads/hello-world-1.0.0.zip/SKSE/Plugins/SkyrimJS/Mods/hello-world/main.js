import { greeting } from "./lib/greeting.js";

skse.console.log("Independent JS mod loaded:", skse.mod.id, skse.mod.version);
skse.onMounted(() => {
    const count = skse.Storage.get("visits") ?? 0;
    skse.Storage.set("visits", count + 1);
    skse.console.log(greeting, "visits:", count + 1, "player health:", skse.player[0].health);
});
