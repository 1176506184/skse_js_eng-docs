// Skyrim.esm: HousecarlWhiterunRef (Lydia). Change these two values for your follower.
// Lydia must already be enabled by her game quest; this demo never enables or spawns actors.
const follower = { plugin: "Skyrim.esm", referenceId: "0x0A2C94" };

skse.onMounted(() => {
    skse.console.log("Press Ctrl + F8 to move the existing follower to the player.");
    skse.input.bindHotkey("Ctrl+F8", () => {
        const hero = skse.getActor(follower);
        if (!hero) return; // The API already wrote the reason to SkyrimJS.log.
        const moved = hero.moveTo(skse.player[0]);
        if (moved) skse.console.log("Move submitted for", hero.name, "reference", hero.formId);
    });
});
