// This is a standalone entry example. Keep your own main.js backed up.
skse.onMounted(() => {
    if (!skse.ui.available) {
        skse.console.error("HTML UI runtime is missing. Install the complete HTML UI package.");
        return;
    }
    const player = skse.player[0];
    let hero = skse.Storage.get("html-ui.hero");
    const panel = skse.ui.open({
        id: "followers-demo",
        url: "./ui/demo/index.html",
        transparent: true,
        input: "exclusive",
        visible: false,
        closeOnEscape: false
    });
    if (!panel) return;
    const toggle = () => {
        if (panel.closed) return;
        if (panel.visible) panel.hide(); else panel.show();
    };
    const unbind = skse.input.bindHotkey("Ctrl++", toggle);
    panel.on("menu:hide", () => panel.hide());
    if (!unbind) { panel.close(); skse.console.error("Could not bind Ctrl++."); return; }
    skse.console.log("HTML UI: press Ctrl + Plus to toggle the menu.");
    let timer;
    function update() {
        panel.send("player:update", { name: player.name, health: player.health, heroName: hero ? hero.name : "未召唤" });
        if (!panel.closed) timer = setTimeout(update, 500);
    }
    panel.on("ready", () => {
        skse.console.log("HTML UI ready");
        clearTimeout(timer);
        update();
    });
    panel.on("hero:spawn", () => {
        if (!hero) {
            hero = skse.new({ formId: "0x001034E4", name: "旅人" });
            if (hero) {
                const position = player.position;
                hero.setPosition({ ...position, x: position.x + 120 });
                skse.Storage.set("html-ui.hero", hero);
            }
        }
        panel.send("notice", hero ? "旅人已准备就绪" : "召唤失败，请查看 SkyrimJS.log");
    });
    panel.on("hero:combat", () => {
        if (hero) { hero.setStatus(skse.statusEnum.combat); panel.send("notice", "旅人已切换为战斗姿态"); }
        else panel.send("notice", "请先召唤旅人");
    });
    panel.on("hero:idle", () => {
        if (hero) { hero.setStatus(skse.statusEnum.idle); panel.send("notice", "旅人已恢复空闲姿态"); }
        else panel.send("notice", "请先召唤旅人");
    });
    panel.on("error", message => skse.console.error("HTML UI:", message));
    panel.on("close", event => {
        unbind();
        clearTimeout(timer);
        skse.console.log("HTML UI closed:", event.reason);
    });
});
