"use strict";
skse.ui.on("player:update", data => {
    document.querySelector("#player-name").textContent = data.name || "玩家";
    document.querySelector("#health").textContent = typeof data.health === "number" ? data.health.toFixed(1) : "—";
    document.querySelector("#hero-name").textContent = data.heroName;
    const summoned = !!data.heroName && data.heroName !== "未召唤";
    document.querySelector("#hero-state").textContent = summoned ? "已召唤" : "等待相遇";
    document.querySelector("#hero-state").classList.toggle("active", summoned);
    document.querySelector("#hero-hint").textContent = summoned ? "旅人已就绪，你可以调整他的姿态。" : "召唤后，可在这里调整角色姿态。";
    document.querySelector("#combat").disabled = !summoned;
    document.querySelector("#idle").disabled = !summoned;
    document.querySelector("#spawn").disabled = summoned;
});
skse.ui.on("notice", text => { document.querySelector("#notice").textContent = String(text); });
document.querySelector("#spawn").onclick = () => skse.ui.send("hero:spawn");
document.querySelector("#combat").onclick = () => skse.ui.send("hero:combat");
document.querySelector("#idle").onclick = () => skse.ui.send("hero:idle");
document.querySelector("#close").onclick = () => skse.ui.send("menu:hide");
